# mask_detector > 2023-11-04 10:34pm
https://universe.roboflow.com/data-science-b47gw/mask_detector-eaes9

Provided by a Roboflow user
License: CC BY 4.0

